﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.ComponentModel;
namespace AdvancedStringReversalAPI
{
    public class Program
    {
        static void Main(string[] args)
        {
            ReverseString();
            IsPalindrome();
            APIEndPoint();
        }
        static void ReverseString() {

            Console.WriteLine("ADVANCED STRING REVERSAL API ");

            Console.WriteLine("***********************************************");
            Console.Write("Enter a string of characters:");
            string letters = Console.ReadLine();

            char[] cha = letters.ToCharArray();
            Array.Reverse(cha);
            foreach (char ch in cha) Console.Write( ch +"\t");


            Console.WriteLine("\n");
            Console.WriteLine("Here is the input string in reverse above and below:" + "\n");
            Console.WriteLine(cha);
        }


        static void IsPalindrome()
        {
            string letters = Console.ReadLine();

            char[] cha = letters.ToCharArray();
            Array.Reverse(cha);
            foreach (char ch in cha) Console.Write(ch + "\t");

            if (cha==cha)

            {
                System.Console.WriteLine("PALINDROME");
                System.Console.WriteLine("The input string is a palindrome");


                Console.WriteLine("***********************************************");

            }
            else if (cha != cha)
               {
                System.Console.WriteLine("PALINDROME");
                System.Console.WriteLine("The input string is not a palindrome");
                Console.WriteLine("***********************************************");
            }

        }

        private static void APIEndPoint()
        {
            System.Console.WriteLine("JSON");

            Console.Write("Enter a Json string:");

            string letters = Console.ReadLine();

            char[] cha = letters.ToCharArray();
            Array.Reverse(cha);
            foreach (char ch in cha) Console.Write(ch + "\t");
            Console.Write("\n");
            Console.WriteLine("Here is the Json string in reverse above and below:" + "\n");
            System.Console.WriteLine(cha);

            if (cha==cha)

            {
                Console.Write("\n");
                System.Console.WriteLine("The Json String is a palindrome");


                Console.WriteLine("***********************************************");

            }
            else if (cha!=cha)
            {

                System.Console.WriteLine("The Json string is not a palindrome");
                Console.WriteLine("***********************************************");
            }







        }



    }
      
    }
    